<template>
  <div class="card" >
    <iframe :src="src" v-if="src"/>
  </div>
</template>

<script>
import $ from "jquery";
export default {
  name: "Card",
  props: {
    url: {
      type: String,
      default: ""
    },
    index: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      src: "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1558032633348&di=f60557ae7047c8810f01921040f8010a&imgtype=0&src=http%3A%2F%2Fhiphotos.baidu.com%2Ffeed%2Fpic%2Fitem%2F10dfa9ec8a136327d1d09ba89d8fa0ec08fac768.jpg",
       timer: null
    };
  },
  mounted() {
    window.addEventListener("scroll", this.scrollFn);
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.scrollFn);
  },
  methods: {
    scrollFn() {
      if (this.inViewReport()) {
        this.setUrl();
      }
    },
    inViewReport() {
      const $el = $(this.$el);
      const $window = $(window);
      const top = $el.offset().top;
      const height = $el.height();
      const windowScrollTop = $window.scrollTop();
      const windowHeight = $window.height();
      if (
        windowScrollTop < top + height &&
        windowScrollTop > top - windowHeight
      ) {
        return true;
      }
      return false;
    },
    setUrl() {
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        if (this.inViewReport()) {
          this.src = this.url;
          console.log(this.index);
          window.removeEventListener("scroll", this.scrollFn);
        }
      }, 500);
    }
  }
};
</script>

<style lang="less" scoped>
.card {
  height: 100%;
  width: 100%;
  iframe {
    height: 100%;
    width: 100%;
    border: 0;
  }
}
</style>

