<template>
  <div class="cardList">
    <a href="#item20">20</a>
    <a href="#item40">40</a>
    <a href="#item60">60</a>
    <div v-for="(item,i) in list" :key="i" class="item" :id="`item${i}`">
      <Card :url="item.url" :index="i"/>
    </div>
  </div>
</template>

<script>
import Card from "./Card";
import $ from "jquery";

export default {
  name: "CardList",
  data() {
    return {
      list: []
    };
  },
  created() {
    this.list.length = 100;
    this.list.fill({ name: "1", url: "https://segmentfault.com/" });
    this.$nextTick(() => {
      console.log("ss");
      document.documentElement.scrollTop = 1;
    });
  },
  components: {
    Card
  }
};
</script>

<style lang="less" scoped>
.cardList {
  .item {
    display: inline-block;
    width: 340px;
    height: 360px;
    border: 1px solid #000;
  }
}
</style>

