<!--
    组件功能: 表格
    开发人: xuwenli526
-->
<template>
  <div class="Mtable">
    <table border="1px">
      <tr-head class="t-head" :columns="columns"></tr-head>
      <tbody class="t-body">
        <tr-row
          v-for="(row,i) in data"
          :key="i"
          :data="data"
          :row="row"
          :columns="columns"
          :index="i"
        ></tr-row>
      </tbody>
    </table>
  </div>
</template>
<script>
/* eslint-disable */
import Vue from "vue";

Vue.component("tr-head", {
  props: {
    columns: {
      type: Array,
      default: () => []
    }
  },
  render() {
    const flatCols = this.flatMap(this.columns); // 降维
    // 对应层级数据
    const layColsMap = flatCols.reduce((prev, cur) => {
      if (!prev[cur._level]) {
        prev[cur._level] = [];
      }
      prev[cur._level].push(cur);
      return prev;
    }, {});
    // 层级数
    const maxLay = Object.keys(layColsMap).length;
    const trRow = [];
    for (let i = 0; i < maxLay; i += 1) {
      const cols = layColsMap[i];
      const tds = [];
      if (i === 0) {
        tds.push(<th rowspan={maxLay}>序号</th>);
      }
      for (let j = 0; j < cols.length; j += 1) {
        let rowspan = 1;
        let colspan = 1;
        if (cols[j].children) {
          colspan = this.flatMap(cols[j].children).length;
        }
        if (!cols[j].children) {
          rowspan = maxLay - i;
        }
        tds.push(
          <th rowspan={rowspan} colspan={colspan}>
            {cols[j].title}
          </th>
        );
      }
      trRow.push(<tr>{tds}</tr>);
    }
    return <thead>{trRow}</thead>;
  },
  methods: {
    flatMap(arr, level = 0) {
      return arr.flatMap(item =>
        item.children
          ? [
              Object.assign(item, { _level: level }),
              ...this.flatMap(item.children, level + 1)
            ]
          : Object.assign(item, { _level: level })
      );
    }
  }
});
Vue.component("tr-row", {
  props: {
    columns: {
      type: Array,
      default: () => []
    },
    data: {
      type: Array,
      default: () => []
    },
    row: {
      type: Object,
      required: true
    },
    index: {
      type: Number,
      required: true
    }
  },
  render() {
    const flatCols = this.flatMap(this.columns); // 降维
    const { index, row } = this;
    const tds = [<td>{index + 1}</td>];
    for (let j = 0; j < flatCols.length; j += 1) {
      const rowspan = this.spanSize(this.data, flatCols, index, j);
      if (rowspan != -1) {
        let icon = null;
        if (rowspan > 1) {
          icon = <i class="icon down" onClick={()=>{this.iconClick(index, rowspan)}}/>;
        }
        tds.push(
          <td rowspan={rowspan}>
            {icon}
            {row[flatCols[j].key]}
          </td>
        );
      }
    }
    return <tr>{tds}</tr>;
  },
  methods: {
    flatMap(arr, level = 0) {
      return arr.flatMap(item =>
        item.children
          ? this.flatMap(item.children, level + 1)
          : Object.assign(item, { _level: level })
      );
    },
    iconClick(index, rowspan){
      // this.$parent.hideRow.push
    },
    spanSize(arr, cols, i, j) {
      let l;
      let len;
      let n;
      let noDraw;
      let ref;
      let ref1;
      let stop;
      let x;
      if (i !== 0) {
        noDraw = true;
        for (
          x = l = 0, ref = j;
          0 <= ref ? l <= ref : l >= ref;
          x = 0 <= ref ? (l += 1) : (l -= 1)
        ) {
          if (arr[i - 1][cols[x].key] !== arr[i][cols[x].key]) {
            noDraw = false;
          }
        }
        if (noDraw) {
          return -1;
        }
      }
      len = 0;
      while (i + len < arr.length) {
        stop = false;
        for (
          x = n = 0, ref1 = j;
          0 <= ref1 ? n <= ref1 : n >= ref1;
          x = 0 <= ref1 ? (n += 1) : (n -= 1)
        ) {
          if (arr[i][cols[x].key] !== arr[i + len][cols[x].key]) {
            stop = true;
          }
        }
        if (stop) {
          break;
        }
        len += 1;
      }
      return len;
    }
  }
});
export default {
  name: "Mtable",
  data() {
    return {
      data: [],
      columns: [],
      hideRow: [],
    };
  },
  created() {
    const obj = this.getData();
    this.data = obj.datas.data;
    this.columns = obj.datas.header;
  },
  methods: {
    getData() {
      return {
        code: "000000",
        msg: "成功",
        datas: {
          cPageNum: "1",
          tPageNum: "1",
          countPerPage: null,
          totalCount: "20",
          header: [
            { title: "专业公司", key: "D0", tId: "CORP_CODE", children: null },
            { title: "持仓日期", key: "D1", tId: "HOLD_DATE", children: null },
            {
              title: "一方资金来源规模",
              key: "M0",
              tId: null,
              children: [
                { title: "寿险", key: "M0", tId: "CORP_CODE", children: null },
                { title: "产险", key: "M1", tId: "CORP_CODE", children: null },
                {
                  title: "养老险",
                  key: "M2",
                  tId: "CORP_CODE",
                  children: null
                },
                {
                  title: "陆金所",
                  key: "M3",
                  tId: "CORP_CODE",
                  children: null
                },
                { title: "资管", key: "M4", tId: "CORP_CODE", children: null },
                { title: "证券", key: "M5", tId: "CORP_CODE", children: null },
                { title: "信托", key: "M6", tId: "CORP_CODE", children: null },
                { title: "基金", key: "M7", tId: "CORP_CODE", children: null },
                {
                  title: "不动产",
                  key: "M8",
                  tId: "CORP_CODE",
                  children: null
                },
                {
                  title: "海外控股",
                  key: "M9",
                  tId: "CORP_CODE",
                  children: null
                }
              ]
            }
          ],
          data: [
            {
              D0: "不动产",
              D1: "20180430",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "6336.00",
              M9: "0.00",
              R: 1
            },
            {
              D0: "不动产",
              D1: "20180430",
              M0: "1.00",
              M1: "1.00",
              M2: "1.00",
              M3: "1.00",
              M4: "1.00",
              M5: "1.00",
              M6: "1.00",
              M7: "1.00",
              M8: "6336.00",
              M9: "0.00",
              R: 1
            },
            {
              D0: "不动产",
              D1: "20180531",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "6336.00",
              M9: "0.00",
              R: 2
            },
            {
              D0: "产险",
              D1: "20180430",
              M0: "0.00",
              M1: "832.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 3
            },
            {
              D0: "产险",
              D1: "20180531",
              M0: "0.00",
              M1: "832.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 4
            },
            {
              D0: "信托",
              D1: "20180430",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "56704.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 5
            },
            {
              D0: "信托",
              D1: "20180531",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "56704.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 6
            },
            {
              D0: "养老险",
              D1: "20180430",
              M0: "0.00",
              M1: "0.00",
              M2: "16704.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 7
            },
            {
              D0: "养老险",
              D1: "20180531",
              M0: "0.00",
              M1: "0.00",
              M2: "16704.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 8
            },
            {
              D0: "基金",
              D1: "20180430",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "5248.00",
              M8: "0.00",
              M9: "0.00",
              R: 9
            },
            {
              D0: "基金",
              D1: "20180531",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "5248.00",
              M8: "0.00",
              M9: "0.00",
              R: 10
            },
            {
              D0: "寿险",
              D1: "20180430",
              M0: "6016.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 11
            },
            {
              D0: "寿险",
              D1: "20180531",
              M0: "6016.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 12
            },
            {
              D0: "海外控股",
              D1: "20180430",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "512.00",
              R: 13
            },
            {
              D0: "海外控股",
              D1: "20180531",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "512.00",
              R: 14
            },
            {
              D0: "证券",
              D1: "20180430",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "2304.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 15
            },
            {
              D0: "证券",
              D1: "20180531",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "0.00",
              M5: "2304.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 16
            },
            {
              D0: "资管",
              D1: "20180430",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "32576.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 17
            },
            {
              D0: "资管",
              D1: "20180531",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "0.00",
              M4: "32576.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 18
            },
            {
              D0: "陆金所",
              D1: "20180430",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "10304.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 19
            },
            {
              D0: "陆金所",
              D1: "20180531",
              M0: "0.00",
              M1: "0.00",
              M2: "0.00",
              M3: "10304.00",
              M4: "0.00",
              M5: "0.00",
              M6: "0.00",
              M7: "0.00",
              M8: "0.00",
              M9: "0.00",
              R: 20
            }
          ],
          totalData: [
            {
              M0: "12032.00",
              M1: "1664.00",
              M2: "33408.00",
              M3: "20608.00",
              M4: "65152.00",
              M5: "4608.00",
              M6: "113408.00",
              M7: "10496.00",
              M8: "12672.00",
              M9: "1024.00"
            }
          ]
        }
      };
    }
  }
};
/* eslint-able */
</script>
<style lang="less" scoped>
.Mtable {
  /deep/ table {
    i.icon {
      display: inline-block;
      height: 12px;
      width: 12px;
      background-size: 100% 100%;
      &.down {
        background-image: url("./down.png");
      }
      &.right {
        background-image: url("./right.png");
      }
    }
    tr {
      td {
        text-align: left;
      }
    }
  }
}
</style>
